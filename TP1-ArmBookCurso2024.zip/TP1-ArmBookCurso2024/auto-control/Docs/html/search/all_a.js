var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['relay_1',['relay',['../main_8cpp.html#a143380ffa75db02df67e6c55246f4799',1,'main.cpp']]]
];
