var searchData=
[
  ['time_5ffor_5fovertime_0',['TIME_FOR_OVERTIME',['../main_8cpp.html#a5876a500afedd2b40bac024b88f30afe',1,'main.cpp']]]
];
