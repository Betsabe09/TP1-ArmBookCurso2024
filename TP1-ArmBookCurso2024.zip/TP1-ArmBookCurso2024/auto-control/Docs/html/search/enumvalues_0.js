var searchData=
[
  ['monitor_0',['MONITOR',['../main_8cpp.html#a808e5cd4979462d3bbe3070d7d147444a92e8e1033650c9fd30199df2d6ec23e7',1,'main.cpp']]]
];
