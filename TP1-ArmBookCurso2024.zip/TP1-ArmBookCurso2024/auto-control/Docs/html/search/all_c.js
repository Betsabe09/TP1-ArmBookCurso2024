var searchData=
[
  ['time_5ffor_5fovertime_0',['TIME_FOR_OVERTIME',['../main_8cpp.html#a5876a500afedd2b40bac024b88f30afe',1,'main.cpp']]],
  ['timer_1',['timer',['../main_8cpp.html#aaf7e0389622e8f7b78393ee10d8e93a4',1,'main.cpp']]],
  ['transitiontostate_2',['transitionToState',['../main_8cpp.html#a61491903ab1762127a45ea94092726af',1,'main.cpp']]]
];
