var searchData=
[
  ['off_0',['OFF',['../main_8cpp.html#a808e5cd4979462d3bbe3070d7d147444aac132f2982b98bcaa3445e535a03ff75',1,'main.cpp']]]
];
