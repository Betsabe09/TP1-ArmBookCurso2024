var searchData=
[
  ['outputsoffset_0',['outputsOffSet',['../main_8cpp.html#a9c83968c1c406c5b20f4c6b14f74f5de',1,'main.cpp']]]
];
