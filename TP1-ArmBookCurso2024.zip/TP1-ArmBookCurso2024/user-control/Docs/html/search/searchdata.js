var indexSectionsWithContent =
{
  0: "bcehilmoprstuw",
  1: "mr",
  2: "bhlmpru",
  3: "cilstw",
  4: "s",
  5: "mop",
  6: "belt",
  7: "cu"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Archivos",
  2: "Funciones",
  3: "Variables",
  4: "Enumeraciones",
  5: "Valores de enumeraciones",
  6: "defines",
  7: "Páginas"
};

