var searchData=
[
  ['confirmationreceived_0',['confirmationReceived',['../main_8cpp.html#a54eaa2aa30ea04e526d829db6cf065c5',1,'main.cpp']]],
  ['control_1',['user-control',['../md__r_e_a_d_m_e.html',1,'']]],
  ['currentstate_2',['currentState',['../main_8cpp.html#a372f8e4da4e6149314fd5c8dd8ae578b',1,'main.cpp']]]
];
