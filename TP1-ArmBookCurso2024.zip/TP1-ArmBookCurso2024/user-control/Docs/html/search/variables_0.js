var searchData=
[
  ['confirmationreceived_0',['confirmationReceived',['../main_8cpp.html#a54eaa2aa30ea04e526d829db6cf065c5',1,'main.cpp']]],
  ['currentstate_1',['currentState',['../main_8cpp.html#a372f8e4da4e6149314fd5c8dd8ae578b',1,'main.cpp']]]
];
